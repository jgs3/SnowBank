config = {
    // global constants

    // Private key that will be used for testnets
    testnetAccounts: ["6f33af14ff2b3d169367365798b1c5e87a97588046b26bbc8e00dcbc374f6293"],
    // Private key that will be used for mainnets
    mainnetAccounts: ["6f33af14ff2b3d169367365798b1c5e87a97588046b26bbc8e00dcbc374f6293"],

    // Project id from https://infura.io/
    infuraIdProject: "abcd1234...",

    // API key from explorers
    apiKeyBase: "N5PMMI1CK29EIF16RI5X1GS8KCPIWTT6X1",
    apiKeyBSC: "PX9RD1I4VVR28HJHI636FFPY55XZUYSKC3",

    nodeUrls: {
        arbitrum: "",

        arbitrumGoerli: "",
        sepolia: "",
    },

    masterChefAddress: "",
    wildTokenAddress: "",
    wildEthPairAddress: "",
    randomizer: "",
    bossGameFactory: "",

    masterChefParams: {
        emissionRate: "3000000000000000000",
        pools: [
            {
                name: "wild",
                pid: 0,
                allocation: 50,
                depositFee: 0,
                withDepositDiscount: false,
            },
            {
                name: "wildEth",
                pid: 1,
                allocation: 400,
                depositFee: 0,
                withDepositDiscount: false,
            },
            {
                name: "wethUsdt",
                pid: 2,
                address: "0xBEb125e43B46F757ece0428cdE20cce336aF962E",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "wethUsdc",
                pid: 3,
                address: "0xC53e453E4A6953887bf447162D1dC9E1e7f16f60",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "wbtcWeth",
                pid: 4,
                address: "0x4CefE08Ea644291626F286DD9223Eaef932560c4",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "arbEth",
                pid: 5,
                address: "0x1713f5d04a741a2dD2d026Ce7cAb5614a499e1c0",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "bananaEth",
                pid: 6,
                address: "0x87870a3F29eC9683d346FFD4f7330Dd1b46264c2",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "onyxEth",
                pid: 7,
                address: "0xB8fCc49ecC9206DaBb48B28ecbcfD31D5C6346D1",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "linkEth",
                pid: 8,
                address: "0x9DD6222E75032C4418f58212A72aedcea2ea3632",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
            {
                name: "daiEth",
                pid: 9,
                address: "0xeBca41a83b658519F9Cf9fEB63CAe9f2A5112023",
                allocation: 10,
                depositFee: 400,
                withDepositDiscount: true,
            },
        ],
    },

    testnet: {
        weth: "0x4200000000000000000000000000000000000006",
        timelockAddress: "0x4e6A028008FC7c289ce76298bA99742BA7ABbD40",
        wildTokenAddress: "0x4dbD77B95890dC034Af56418e61Fcb642d0Dc525",
        randomizer: "0x923096Da90a3b60eb7E12723fA2E1547BA9236Bc",
        bossGameFactory: "0x82947C48667323f777Ed86a3Cbf30AB07000347d",
    },
};

config.masterChefParams.pools[0].address = config.wildTokenAddress;
config.masterChefParams.pools[1].address = config.wildEthPairAddress;

module.exports = config;
