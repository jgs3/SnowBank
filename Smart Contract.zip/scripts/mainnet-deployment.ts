import { ethers } from "hardhat";
const utils = require("../scripts/utils");

const config = {
    factory: "0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73",
    router: "0x10ED43C718714eb63d5aA57B78B54704E256024E",
    startBlock: 329950000, //Date and time (GMT): Thursday, September 7, 2023 2:22:25 PM
    devAddress: "0xAE02196968A374A2d1281eD082F7A66b510FA8aD",
    feeAddress: "0xAE02196968A374A2d1281eD082F7A66b510FA8aD",
    deployerAddress: '0x600bE5FcB9338BC3938e4790EFBeAaa4F77D6893',
    wild: "0x58E916635A8D406B459C1c6009FC4f981E7a21a4",
    usdc: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
    weth: "0x4DB5a66E937A9F4473fA95b1cAF1d1E1D62E29EA",
    baseLp: "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c",
    masterChefAddress: "0xaEce7BDBf2806cc8ed55C189D1519bd3113Bdc06",
};

async function main() {
    const [deployer] = await ethers.getSigners();

    console.log("deployer address:", deployer.address);
    const factory = await ethers.getContractAt("PancakeFactory", config.factory);
    const router = await ethers.getContractAt("PancakeRouter", config.router);

    const token = await utils.deployAndVerify("WildToken", [config.usdc, config.router]);

    // const token = await ethers.getContractAt("WildToken", config.wild);

    await token.mint(config.deployerAddress, ethers.utils.parseEther("500000"));

    const masterChef = await utils.deployAndVerify("MasterChef", [
        token.address,
        config.deployerAddress, //dev address
        config.deployerAddress, //fee address
        0,
        config.startBlock,
    ]);

    await token.transferOwnership(masterChef.address);

    // const masterChef = await ethers.getContractAt("WildMasterChef", config.masterChefAddress);



    const wildWethPair = await factory.getPair(config.weth, token.address);
    const usdcWethPair = await factory.getPair(config.usdc, token.address);
    const wethUSDCPair = await factory.getPair(config.usdc, config.weth);

    await masterChef.add(500, token.address, 0, false);
    await masterChef.add(950, wildWethPair, 0, false);
    await masterChef.add(0, wethUSDCPair, 400, false);

    console.log({
        // wildWethPair: wildWethPair,
        // usdcWethPair: usdcWethPair,
        wethUSDCPair: wethUSDCPair,
        // wildDaiPair: wildDaiPair,
        // wildMimPair: wildMimPair,
    });

    // await masterChef.add(800, wildWethPair, 200, false, false);
    // await masterChef.add(200, wildUsdcPair, 200, false, false);
    // await masterChef.add(200, wildDaiPair, 200, false, false);
    // await masterChef.add(200, wildMimPair, 200, false, false);

    const zapper = await utils.deployAndVerify("ZapV3");

    await zapper.setCoreValues(
        config.router,
        config.factory,
        token.address,
        wildWethPair,
        config.weth
    );

    console.log({
        token: token.address,
        masterChef: masterChef.address,
        zapper: zapper.address,
    });
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
