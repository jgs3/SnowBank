module.exports = {
    skipFiles: ["test/", "echidna-test/"],
};
